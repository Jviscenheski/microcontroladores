// main.c
// Desenvolvido para a placa EK-TM4C1294XL
// Verifica o currentState das chaves USR_SW1 e USR_SW2, acende os LEDs 1 e 2 caso estejam pressionadas independentemente
// Caso as duas chaves estejam pressionadas ao mesmo tempo pisca os LEDs alternadamente a cada 500ms.
// Prof. Guilherme Peron

#include "tm4c1294ncpdt.h"
#include <stdint.h>

void PLL_Init(void);
void SysTick_Init(void);
void SysTick_Wait1ms(uint32_t delay);
void GPIO_Init(void);
uint32_t PortJ_Input(void);
void Port_Output(uint32_t N, uint32_t F);
void Pisca_leds(void);
void Interrupt(void);

char pedestresFlag = 0;

typedef enum semaforo
{
	redRed_init,
	piscaState,
	redGreen,
	redYellow,
	redRed,
	greenRed,
	yellowRed
	
} semaforoStates;

semaforoStates currentState = redRed_init;

int main(void)
{
	PLL_Init();
	SysTick_Init();
	GPIO_Init();
	Interrupt();	
	
	while (1)
	{
		switch(currentState) {
			case redRed_init:
				if(pedestresFlag){
					currentState = piscaState;
				}
				else {
					Port_Output(0x3, 0x11);
					SysTick_Wait1ms(1000);
					currentState = redGreen;
				}
				break;
			case redGreen:
				Port_Output(0x3, 0x10);
				SysTick_Wait1ms(6000);
				currentState = redYellow;
				break;
			case redYellow:
				Port_Output(0x3, 0x1);
				SysTick_Wait1ms(2000);
				currentState = redRed; 
				break;
			case redRed:
				Port_Output(0x3, 0x11);
				SysTick_Wait1ms(1000);
				currentState = greenRed;
				break;
			case greenRed:
				Port_Output(0x2, 0x11);
				SysTick_Wait1ms(6000);
				currentState = yellowRed;
				break;
			case yellowRed:
				Port_Output(0x1, 0x11);
				SysTick_Wait1ms(2000);
				currentState = redRed_init;
				break;
			case piscaState:
				Pisca_leds();
				pedestresFlag = 0;
				currentState = redGreen;
				break;
		}  
	}
}

void Pisca_leds(void)
{
	for(char index = 0; index < 10; index++) {
		Port_Output(0x1, 0x1);
		SysTick_Wait1ms(250);
		Port_Output(0x2, 0x10);
		SysTick_Wait1ms(250);
	}
}

void GPIOPortJ_Handler(void) 
{
	pedestresFlag = 1;
	GPIO_PORTJ_AHB_ICR_R |= 0x3;
}
