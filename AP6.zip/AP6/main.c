// main.c
// Desenvolvido para a placa EK-TM4C1294XL
// Verifica o currentState das chaves USR_SW1 e USR_SW2, acende os LEDs 1 e 2 caso estejam pressionadas independentemente
// Caso as duas chaves estejam pressionadas ao mesmo tempo pisca os LEDs alternadamente a cada 500ms.
// Prof. Guilherme Peron

#include "tm4c1294ncpdt.h"
#include <stdint.h>

void PLL_Init(void);
void SysTick_Init(void);
void SysTick_Wait1ms(uint32_t delay);
void GPIO_Init(void);
uint32_t PortJ_Input(void);
void Interrupt(void);
void TIMER2_Init(void);
void UART0_Init(void);
uint8_t Uart0_Rcv(void);
void Uart0_Send(uint8_t charactere);
void Uart0_Send_Msg(uint8_t* msg, int32_t size);

int32_t led=0;
float dutycycle=1;

int main(void)
{
	PLL_Init();
	SysTick_Init();
	UART0_Init();
	GPIO_Init();
	Interrupt();	
	TIMER2_Init();
	Uart0_Send_Msg("\r\nStart 1%", 10);

	while (1)
	{
		uint8_t recebido = Uart0_Rcv();
		
		if(recebido == '0') {
			Uart0_Send_Msg("\r\nLED a 1%", 10);
			dutycycle = 1;
		}
		else if(recebido == '1') {
			Uart0_Send_Msg("\r\nLED a 20%", 11);
			dutycycle = 20;
		}
		else if(recebido == '2') {
			Uart0_Send_Msg("\r\nLED a 40%", 11);
			dutycycle = 40;
		}
		else if(recebido == '3') {
			Uart0_Send_Msg("\r\nLED a 60%", 11);
			dutycycle = 60;
		}
		else if(recebido == '4') {
			Uart0_Send_Msg("\r\nLED a 80%", 11);
			dutycycle = 80;
		}
		else if(recebido == '5') {
			Uart0_Send_Msg("\r\nLED a 99%", 11);
			dutycycle = 99;
		}	
	}  
	
}


void GPIOPortJ_Handler(void) 
{
	GPIO_PORTJ_AHB_ICR_R |= 0x3;
	//9. Habilitar e desabilita TIMER_CTL_R para fazer as configura��es
	TIMER2_CTL_R^=TIMER_CTL_TAEN;
}

void Timer2A_Handler(void) 
{
	TIMER2_CTL_R&=~(TIMER_CTL_TAEN);
	TIMER2_ICR_R|=TIMER_ICR_TATOCINT;
	if(led ==0 )
	{
		TIMER2_TAILR_R=(79999*(dutycycle))/100;
		led=1;
	}
	else
	{
		TIMER2_TAILR_R=(79999*(100-dutycycle))/100;
		led=0;
	}
	TIMER2_CTL_R|=TIMER_CTL_TAEN;
		
	GPIO_PORTF_AHB_DATA_R ^= 1;

}
