// main.c
// Desenvolvido para a placa EK-TM4C1294XL
// Verifica o currentState das chaves USR_SW1 e USR_SW2, acende os LEDs 1 e 2 caso estejam pressionadas independentemente
// Caso as duas chaves estejam pressionadas ao mesmo tempo pisca os LEDs alternadamente a cada 500ms.
// Prof. Guilherme Peron

#include "tm4c1294ncpdt.h"
#include <stdint.h>

void PLL_Init(void);
void SysTick_Init(void);
void SysTick_Wait1ms(uint32_t delay);
void GPIO_Init(void);
uint32_t PortJ_Input(void);
void Interrupt(void);
void TIMER_Init(void);

int main(void)
{
	PLL_Init();
	SysTick_Init();
	GPIO_Init();
	Interrupt();	
	TIMER_Init();
	
	while (1)
	{
	
	}  
	
}


void GPIOPortJ_Handler(void) 
{
	GPIO_PORTJ_AHB_ICR_R |= 0x3;
	//9. Habilitar e desabilita TIMER_CTL_R para fazer as configura��es
	TIMER2_CTL_R^=TIMER_CTL_TAEN;
}

void Timer2A_Handler(void) 
{
	TIMER2_ICR_R|=TIMER_ICR_TATOCINT;

	GPIO_PORTF_AHB_DATA_R ^= 1;

}
