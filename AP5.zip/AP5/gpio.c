// gpio.c
// Desenvolvido para a placa EK-TM4C1294XL
// Inicializa as portas J, F e N
// Prof. Guilherme Peron


#include <stdint.h>

#include "tm4c1294ncpdt.h"

  
#define GPIO_PORTJ  (0x0100) //bit 8
#define GPIO_PORTN  (0x1000) //bit 12
#define GPIO_PORTF  (0x0020) //bit 5
#define TIMER2  (0x0004) //bit 3

// -------------------------------------------------------------------------------
// Fun��o GPIO_Init
// Inicializa os ports J e N
// Par�metro de entrada: N�o tem
// Par�metro de sa�da: N�o tem
void GPIO_Init(void)
{
	//1a. Ativar o clock para a porta setando o bit correspondente no registrador RCGCGPIO
	SYSCTL_RCGCGPIO_R = (GPIO_PORTJ | GPIO_PORTN | GPIO_PORTF);
	
	//1b.   ap�s isso verificar no PRGPIO se a porta est� pronta para uso.
  while((SYSCTL_PRGPIO_R & (GPIO_PORTJ | GPIO_PORTN | GPIO_PORTF) ) != (GPIO_PORTJ | GPIO_PORTN | GPIO_PORTF) ){};
	
	// 2. Limpar o AMSEL para desabilitar a anal�gica
	GPIO_PORTJ_AHB_AMSEL_R = 0x00;
	GPIO_PORTN_AMSEL_R = 0x00;
	GPIO_PORTF_AHB_AMSEL_R = 0x00;
		
	// 3. Limpar PCTL para selecionar o GPIO
	GPIO_PORTJ_AHB_PCTL_R = 0x00;
	GPIO_PORTN_PCTL_R = 0x00;
	GPIO_PORTF_AHB_PCTL_R = 0x00;
		
	// 4. DIR para 0 se for entrada, 1 se for sa�da
	GPIO_PORTJ_AHB_DIR_R = 0x00;
	GPIO_PORTN_DIR_R = 0x03; //BIT0 | BIT1
	GPIO_PORTF_AHB_DIR_R = 0x11; //BIT0 | BIT4
		
	// 5. Limpar os bits AFSEL para 0 para selecionar GPIO sem fun��o alternativa	
	GPIO_PORTJ_AHB_AFSEL_R = 0x00;
	GPIO_PORTN_AFSEL_R = 0x00; 
	GPIO_PORTF_AHB_AFSEL_R = 0x00; 
		
	// 6. Setar os bits de DEN para habilitar I/O digital	
	GPIO_PORTJ_AHB_DEN_R = 0x03;   //Bit0 e bit1
	GPIO_PORTN_DEN_R = 0x03; 		   //Bit0 e bit1
	GPIO_PORTF_AHB_DEN_R = 0x11; 		   //Bit0 e bit4
	
	// 7. Habilitar resistor de pull-up interno, setar PUR para 1
	GPIO_PORTJ_AHB_PUR_R = 0x03;   //Bit0 e bit1	

}	
// -------------------------------------------------------------------------------
// Fun��o PortJ_Input
// L� os valores de entrada do port J
// Par�metro de entrada: N�o tem
// Par�metro de sa�da: o valor da leitura do port

void TIMER_Init(void)
{
	//1a. Ativar o clock para a porta setando o bit correspondente no registrador RCGCTIMER
	SYSCTL_RCGCTIMER_R = (TIMER2);
	
	//1b.   ap�s isso verificar no PRGPIO se a porta est� pronta para uso.
  while((SYSCTL_PRTIMER_R & (TIMER2) ) != (TIMER2)  ){};

	//2. Desabilitar o TIMER_CTL_R para fazer as configura��es
	TIMER2_CTL_R&=~(TIMER_CTL_TAEN);
		
	//3. Seleciona o modo 32 bits no registrador GPTMCFG
	TIMER2_CFG_R&=~(0x07);
	TIMER2_CFG_R|=TIMER_CFG_32_BIT_TIMER;

	//4. Seleciona o modo contador periodico registrador GPTMTAMR
	TIMER2_TAMR_R&=~(0x03);
	TIMER2_TAMR_R|=TIMER_TAMR_TAMR_PERIOD;

	//5. Carrega o valor de contagem no registrador do timer A GPTMTAILR
	TIMER2_TAILR_R=55999999;

	//6. Zera o prescale do Timer A GPTMTAPR
	TIMER2_TAPR_R&=~(0xFF);
	
	//7. Setar o bit para 1 no registrador GPTMICR para zerar o flag de atendimento de interrup��o (ACK)
	TIMER2_ICR_R|=TIMER_ICR_TATOCINT;		

	//8. Setar bit para 1 no registrador GPTMIMR para setar a interrup��o do timer 2A
	TIMER2_IMR_R|=TIMER_IMR_TATOIM;		

	//8b. Setar prioridade de interrup��o no registrador PRIO 5 para a interrup��o de numero 23
	NVIC_PRI5_R=4 << 29;		
	//NVIC_PRI5_R= ~(NVIC_PRI5_INT23_M) Poderia ser uma op��o para zerar a prioridade da interrup��o de numero 23 sem afetar o resto das interrup��es
	
	//8c. Habilitar a interrup��o do timer 2A
	NVIC_EN0_R=1 << 23;		

	//9. Habilitar o TIMER_CTL_R para fazer as configura��es
//	TIMER2_CTL_R|=TIMER_CTL_TAEN;

}
uint32_t PortJ_Input(void)
{
	return GPIO_PORTJ_AHB_DATA_R;
}

// -------------------------------------------------------------------------------
// Fun��o PortN_Output
// Escreve os valores no port N
// Par�metro de entrada: Valor a ser escrito
// Par�metro de sa�da: n�o tem
void Port_Output(uint32_t N, uint32_t F)
{
    
		GPIO_PORTN_DATA_R &= ~(0x3); 
	
		GPIO_PORTF_AHB_DATA_R &= (0xEE);

    GPIO_PORTN_DATA_R |= N; 
	
		GPIO_PORTF_AHB_DATA_R |= F;
}




